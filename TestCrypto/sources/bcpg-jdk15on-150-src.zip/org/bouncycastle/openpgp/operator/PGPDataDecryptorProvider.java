package org.bouncycastle.openpgp.operator;

public interface PGPDataDecryptorProvider
{
}
